create definer = root@localhost trigger trg_BaoTri_AfterInsert
    after insert
    on baotri
    for each row
BEGIN
    -- Cập nhật tình trạng
    UPDATE THIETBI
    SET TinhTrang = 'Đang bảo trì'
    WHERE MaTB = NEW.MaTB;

    -- Thêm vào lịch sử
    INSERT INTO LICH_SU_TB(MaTB, NgayCapNhat, TinhTrangMoi, NguoiCapNhat, GhiChu)
    VALUES (NEW.MaTB, NOW(), 'Đang bảo trì', NEW.NhanVienPhuTrach, NEW.NoiDung);
END;

