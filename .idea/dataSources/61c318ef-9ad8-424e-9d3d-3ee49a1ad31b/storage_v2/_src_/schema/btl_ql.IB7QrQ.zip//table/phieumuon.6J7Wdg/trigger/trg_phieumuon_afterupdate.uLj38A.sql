create definer = root@localhost trigger trg_PhieuMuon_AfterUpdate
    after update
    on phieumuon
    for each row
BEGIN
    -- Nếu thời điểm trả thay đổi từ NULL sang có giá trị => trả thiết bị
    IF OLD.ThoiDiemTra IS NULL AND NEW.ThoiDiemTra IS NOT NULL THEN
        -- Cập nhật tình trạng tất cả thiết bị trong phiếu mượn
        UPDATE THIETBI t
        JOIN CTPHIEUMUON c ON t.MaTB = c.MaTB AND c.MaPM = NEW.MaPM
        SET t.TinhTrang = 'Đang sử dụng';

        -- Ghi vào lịch sử
        INSERT INTO LICH_SU_TB(MaTB, NgayCapNhat, TinhTrangMoi, NguoiCapNhat, GhiChu)
        SELECT c.MaTB, NOW(), 'Đang sử dụng', NEW.NguoiLapPhieu, 'Trả thiết bị'
        FROM CTPHIEUMUON c
        WHERE c.MaPM = NEW.MaPM;
    END IF;
END;

