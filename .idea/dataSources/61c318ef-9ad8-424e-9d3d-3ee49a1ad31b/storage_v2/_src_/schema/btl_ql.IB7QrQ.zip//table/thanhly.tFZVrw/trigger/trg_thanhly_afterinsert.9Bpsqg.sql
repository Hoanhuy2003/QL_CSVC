create definer = root@localhost trigger trg_ThanhLy_AfterInsert
    after insert
    on thanhly
    for each row
BEGIN
    -- Cập nhật tình trạng thiết bị
    UPDATE THIETBI
    SET TinhTrang = 'Đã thanh lý'
    WHERE MaTB = NEW.MaTB;

    -- Ghi vào lịch sử
    INSERT INTO LICH_SU_TB(MaTB, NgayCapNhat, TinhTrangMoi, GhiChu)
    VALUES (NEW.MaTB, NOW(), 'Đã thanh lý', CONCAT('Thanh lý, lý do: ', NEW.LyDo));
END;

