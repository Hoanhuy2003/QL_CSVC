create definer = root@localhost trigger trg_CTPhieuMuon_AfterInsert
    after insert
    on ctphieumuon
    for each row
BEGIN
    -- Cập nhật tình trạng thiết bị
    UPDATE THIETBI
    SET TinhTrang = 'Đang mượn'
    WHERE MaTB = NEW.MaTB;

    -- Thêm vào lịch sử thiết bị
    INSERT INTO LICH_SU_TB(MaTB, NgayCapNhat, TinhTrangMoi, NguoiCapNhat, GhiChu)
    VALUES (NEW.MaTB, NOW(), 'Đang mượn', (SELECT NguoiLapPhieu FROM PHIEUMUON WHERE MaPM = NEW.MaPM),
    CONCAT('Mượn bởi sinh viên ', NEW.MaSV));
END;

